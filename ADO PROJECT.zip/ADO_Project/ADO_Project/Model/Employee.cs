﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Project.Model
{
    class Employee
    {
        public int Empid { get; set; }
        public string Empname { get; set; }
        public string DOB { get; set; }
        public long Phone { get; set; }
        public string Email { get; set; }
        public float Salary { get; set; }
        public int Deptid { get; set; }
    }
}
