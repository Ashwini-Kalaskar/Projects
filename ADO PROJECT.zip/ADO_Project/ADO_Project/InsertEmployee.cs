﻿using ADO_Project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project
{
    public partial class InsertEmployee : Form
    {
        Logic ob;
        public InsertEmployee()
        {
            InitializeComponent();
            ob = new Logic();
        }

        private void EmployeeInsert_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Empid = Convert.ToInt32(tbeid.Text);
            emp.Empname = tbename.Text.ToString();
            emp.DOB = tbdob.Text.ToString();
            emp.Phone = Convert.ToInt64(tbphone.Text);
            emp.Email = tbemail.Text.ToString();
            emp.Salary = float.Parse(tbsalary.Text);
            emp.Deptid = Convert.ToInt32(tbdid.Text);

            string msg = ob.addsp(emp);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllData();
            tbeid.Text = "";
            tbename.Text = "";
            tbdob.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tbsalary.Text = "";
            tbdid.Text = "";
        }
    }
}
