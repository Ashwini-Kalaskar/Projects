﻿namespace ADO_Project
{
    partial class InsertDept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbdid = new System.Windows.Forms.TextBox();
            this.btninsert = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbdname = new System.Windows.Forms.TextBox();
            this.tbloc = new System.Windows.Forms.TextBox();
            this.tbeid = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(145, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "DEPTID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tbdid
            // 
            this.tbdid.Location = new System.Drawing.Point(285, 63);
            this.tbdid.Name = "tbdid";
            this.tbdid.Size = new System.Drawing.Size(173, 22);
            this.tbdid.TabIndex = 1;
            this.tbdid.TextChanged += new System.EventHandler(this.tbdid_TextChanged);
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(523, 127);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(127, 45);
            this.btninsert.TabIndex = 2;
            this.btninsert.Text = "INSERT";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(61, 252);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(681, 176);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "DEPTNAME";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "DEPTLOCATION";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(145, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "MANAGERID";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tbdname
            // 
            this.tbdname.Location = new System.Drawing.Point(285, 109);
            this.tbdname.Name = "tbdname";
            this.tbdname.Size = new System.Drawing.Size(173, 22);
            this.tbdname.TabIndex = 7;
            this.tbdname.TextChanged += new System.EventHandler(this.tbdname_TextChanged);
            // 
            // tbloc
            // 
            this.tbloc.Location = new System.Drawing.Point(285, 155);
            this.tbloc.Name = "tbloc";
            this.tbloc.Size = new System.Drawing.Size(173, 22);
            this.tbloc.TabIndex = 8;
            this.tbloc.TextChanged += new System.EventHandler(this.tbloc_TextChanged);
            // 
            // tbeid
            // 
            this.tbeid.Location = new System.Drawing.Point(285, 205);
            this.tbeid.Name = "tbeid";
            this.tbeid.Size = new System.Drawing.Size(173, 22);
            this.tbeid.TabIndex = 9;
            this.tbeid.TextChanged += new System.EventHandler(this.tbeid_TextChanged);
            // 
            // InsertDept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbeid);
            this.Controls.Add(this.tbloc);
            this.Controls.Add(this.tbdname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.tbdid);
            this.Controls.Add(this.label1);
            this.Name = "InsertDept";
            this.Text = "InsertDept";
            this.Load += new System.EventHandler(this.InsertDept_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbdid;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbdname;
        private System.Windows.Forms.TextBox tbloc;
        private System.Windows.Forms.TextBox tbeid;
    }
}